// package ABES;
// import KIET.*;

// public class EmployeeABES extends EmployeeKIET{
//         public static void main(String[] args) {
//         EmployeeABES ea = new EmployeeABES();
//         ea.Emp_Name = "Yash ABES";
//         ea.Emp_ID = 301;
//         // ea.Org = "ABES";
//         // ea.Salary = 30000;

//         // ea.EmployeeDetails();
//     }
// }
