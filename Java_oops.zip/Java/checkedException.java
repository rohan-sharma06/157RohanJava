// import java.io.FileInputStream;


// public class checkedException {
//     public static void main(String[] args) {
//         try{
//             FileInputStream fs = new FileInputStream("abc.txt");
//         }
//     }
// }
