package KIET;

public class HRDepartment {
    public static void main(String args[]){


        EmployeeKiet e = new EmployeeKiet();
        e.Emp_name = "Yash";
        // e.salary = 9087653;
        e.Emp_id = 7098;
        e.Organisation = "KIET";
        e.employeeDatails();
    }
}
